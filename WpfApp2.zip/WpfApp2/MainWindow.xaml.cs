﻿using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System.Data;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfApp2.Context;
namespace WpfApp2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public LibraryContext _DbContext { get; set; }
        public string tablecurrent { get; set; }
        private void LoadTableNames()
        {
            try
            {
                List<string> tableNames = GetTableNames();
                combo1.ItemsSource = tableNames;
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
        }
        private List<string> GetTableNames()
        {
            List<string> tableNames = new List<string>();
            string q = "SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_TYPE = 'BASE TABLE'";
            using (var command = _DbContext.Database.GetDbConnection().CreateCommand())
            {
                command.CommandText = q;
                _DbContext.Database.OpenConnection();
                using (var result = command.ExecuteReader())
                {
                    while (result.Read())
                    {
                        tableNames.Add(result.GetString(0));
                    }
                }
                _DbContext.Database.CloseConnection();
            }
            return tableNames;
        }
        public MainWindow()
        {
            InitializeComponent();
            _DbContext = new LibraryContext();
            LoadTableNames();
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string? table = combo1.SelectedItem as string;
            if (table is not null)
            {
                tablecurrent = table;
                using (var command = _DbContext.Database.GetDbConnection().CreateCommand())
                {
                    command.CommandText = $"SELECT * FROM {table}";
                    _DbContext.Database.OpenConnection();
                    using (var reader = command.ExecuteReader())
                    {
                        DataTable dataTable = new DataTable();
                        dataTable.Load(reader);
                        grid1.ItemsSource = dataTable.DefaultView;
                    }
                    _DbContext.Database.CloseConnection();
                }
            }
        }
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            var item = grid1.SelectedItem as DataRowView;
            if (item != null)
            {
                var id = Convert.ToInt32(item["Id"]);
                deletebyid(id);
            }
        }
        private void deletebyid(int id)
        {
            using (var command = _DbContext.Database.GetDbConnection().CreateCommand())
            {
                command.CommandText = $"DELETE FROM {tablecurrent} WHERE Id = @Id";
                var p = command.CreateParameter();
                p.ParameterName = "@Id";
                p.Value = id;
                command.Parameters.Add(p);
                _DbContext.Database.OpenConnection();
                command.ExecuteNonQuery();
                _DbContext.Database.CloseConnection();
            }
            MessageBox.Show("Silindi");
        }
    }
}